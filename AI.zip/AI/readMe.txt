This folder has some python files related to machine learning and artificial intelligence. Note: you may need to install some third party python modules to run specific programs.

Thanks,
Josh